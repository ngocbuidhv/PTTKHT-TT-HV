# Thiết kế dữ liệu đề xuất cho cổng sinh viên Đại học Vinh

**Phạm vi:** hồ sơ/danh tính, CTĐT, đăng ký học, lịch học, kết quả học phần, tài chính và thông báo. Đây là mô hình logic đề xuất gồm 33 bảng, không phải bản trích xuất CSDL của trường.

Nguồn khảo sát: HTML/JavaScript công khai của https://congsv.vinhuni.edu.vn/ và cấu hình public của ứng dụng. Tên `tbl_*` quan sát là tài nguyên/service/DTO; chưa xác nhận là bảng SQL. Không có SQL dump, ORM schema hay quyền quản trị CSDL. Giao diện sau đăng nhập không được dùng làm bằng chứng nếu chưa kiểm chứng.

**Đọc sơ đồ:** PK = khóa chính đề xuất; FK = khóa ngoại đề xuất; UK = duy nhất đề xuất; dấu `?` = cho phép rỗng. Nét liền cho biết frontend thể hiện liên kết tương ứng, không chứng minh tồn tại FK vật lý; nét đứt là suy luận nghiệp vụ. Mọi cardinality, kiểu dữ liệu, tên cột và ràng buộc PK/FK hiển thị là lựa chọn thiết kế cần xác nhận. Một số trường gốc bắt đầu bằng `id` thực tế được frontend nối qua `code`, `soChuongTrinhDaoTao` hoặc `instanceId`; không chuyển chúng thành FK số nguyên một cách mặc định.

Toàn bộ định danh `bigint` trong sơ đồ là khóa nội bộ của thiết kế đề xuất. Mã sinh viên, học phần, cán bộ, phòng và mã nghiệp vụ được bảo toàn ở cột mã riêng. Kiểu `decimal` phải triển khai với precision/scale phù hợp tiền hoặc điểm; chưa biết kiểu SQL gốc.

## Xem sơ đồ

- [Trình xem HTML có phóng to, tìm bảng và bằng chứng](index.html)
- [Toàn cảnh SVG](00-tong-quan.svg) · [PDF](00-tong-quan.pdf)
- [Hồ sơ và danh tính — SVG](01-ho-so.svg) · [PNG](01-ho-so.png) · [PDF](01-ho-so.pdf)
- [Chương trình đào tạo — SVG](02-chuong-trinh.svg) · [PNG](02-chuong-trinh.png) · [PDF](02-chuong-trinh.pdf)
- [Đăng ký, lịch học và kết quả — SVG](03-hoc-vu.svg) · [PNG](03-hoc-vu.png) · [PDF](03-hoc-vu.pdf)
- [Khoản thu, giao dịch, biên lai và hóa đơn — SVG](04-tai-chinh.svg) · [PNG](04-tai-chinh.png) · [PDF](04-tai-chinh.pdf)
- [Thông báo chung và trạng thái đọc — SVG](05-thong-bao.svg) · [PNG](05-thong-bao.png) · [PDF](05-thong-bao.pdf)

## Danh mục bảng, trường và bằng chứng

### KHOA_VIEN — Khoa / viện

Tài nguyên đối chiếu: `Danh mục khoa/viện`.

Bằng chứng frontend: Hồ sơ người học và lớp hành chính sử dụng idKhoaVien / idKhoa.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| ma | text | UK |
| ten | text |  |

Tên bảng, PK và kiểu dữ liệu ở đây là đề xuất chuẩn hóa.

### NGANH_HOC — Ngành học

Tài nguyên đối chiếu: `Danh mục ngành`.

Bằng chứng frontend: Hồ sơ, lớp hành chính và CTĐT dùng idNganh.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| khoa_vien_id | bigint | FK |
| ma | text | UK |
| ten | text |  |

### KHOA_HOC — Khóa tuyển sinh

Tài nguyên đối chiếu: `Danh mục khóa học`.

Bằng chứng frontend: Hồ sơ, lớp hành chính và CTĐT dùng idKhoaHoc.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| ma | text | UK |
| ten | text |  |
| nam_bat_dau | int |  |
| nam_ket_thuc | int |  |

Năm bắt đầu/kết thúc là thuộc tính thiết kế bổ sung; không đồng nhất khóa học với năm học.

### LOP_HANH_CHINH — Lớp hành chính

Tài nguyên đối chiếu: `tbl_DanhSach_LopHanhChinh`.

Bằng chứng frontend: id, ten; bộ lọc idHe, idKhoaHoc, idKhoa, idNganh.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| nganh_id | bigint | FK |
| khoa_hoc_id | bigint | FK |
| ma | text | UK |
| ten | text |  |

### SINH_VIEN — Hồ sơ sinh viên

Tài nguyên đối chiếu: `tbl_NguoiHoc_HoSo`.

Bằng chứng frontend: id, code, fullName, idKhoaHoc, idKhoaVien, idNganh, idLopHienTai; form có idLopHanhChinh.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| ma_sinh_vien | text | UK |
| ho_ten | text |  |
| lop_hanh_chinh_id | bigint | FK? |
| nganh_id | bigint | FK |
| khoa_hoc_id | bigint | FK |

ma_sinh_vien ánh xạ code. Đây là mô hình người học hiện tại; lịch sử chuyển lớp/ngành cần bảng bổ sung nếu nằm trong phạm vi dự án.

### TAI_KHOAN — Tài khoản / danh tính

Tài nguyên đối chiếu: `organizationmanagement/user`.

Bằng chứng frontend: userId, userName, maNguoiHoc, originId (claim sub), userType, role.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK? |
| oidc_subject | text | UK |
| ten_dang_nhap | text | UK |
| loai_nguoi_dung | text |  |

Không thiết kế cột mật khẩu cho cổng: xác thực qua nhà cung cấp OIDC. Số tài khoản trên mỗi người học chưa xác minh; mô hình cho phép 0..N.

### CHUONG_TRINH_DAO_TAO — Chương trình đào tạo

Tài nguyên đối chiếu: `tbl_ChuongTrinhDaoTao`.

Bằng chứng frontend: id, code, ten, idKhoaHoc, idNganh, soChuongTrinhDaoTao.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| nganh_id | bigint | FK |
| khoa_hoc_id | bigint | FK |
| ma | text | UK |
| ten | text |  |

code và soChuongTrinhDaoTao là hai định danh khác; form hồ sơ chọn CTĐT qua soChuongTrinhDaoTao. Khi triển khai cần giữ đúng ánh xạ, không coi chúng là một khóa.

### SINH_VIEN_CTDT — Chương trình của sinh viên

Tài nguyên đối chiếu: `tbl_NguoiHoc_Lop`.

Bằng chứng frontend: Filter idNguoiHoc, idLoaiNganh; kết quả có idChuongTrinhDaoTao.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK |
| chuong_trinh_id | bigint | FK |
| loai_nganh | text |  |
| trang_thai | text |  |

Bảng nối đề xuất để hỗ trợ chương trình chính/ngành hai và lịch sử; khóa nội bộ không đồng nhất các mã gốc. UNIQUE(sinh_vien_id,chuong_trinh_id) nếu mỗi lần theo chương trình cập nhật cùng dòng; trường hợp nhiều giai đoạn cần khóa bổ sung.

### HOC_PHAN — Học phần

Tài nguyên đối chiếu: `tbl_HocPhan`.

Bằng chứng frontend: id, instanceId, code, ten, soTinChi, idHe, instanceIdDM_CongThucTinhDiem.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| ma_hoc_phan | text | UK |
| ten | text |  |
| so_tin_chi | int |  |

Học phần là môn trong chương trình; lớp học phần là một lần mở lớp cho môn đó.

### NHOM_TU_CHON — Nhóm tự chọn

Tài nguyên đối chiếu: `tbl_ChuongTrinhDaoTao_NhomTuChon`.

Bằng chứng frontend: id, idChuongTrinhDaoTao, idKhoiKienThuc, soTinChi.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| chuong_trinh_id | bigint | FK |
| ten | text |  |
| so_tin_chi_can_dat | int |  |

### CTDT_HOC_PHAN — Học phần trong CTĐT

Tài nguyên đối chiếu: `tbl_ChuongTrinhDaoTao_HocPhan`.

Bằng chứng frontend: idChuongTrinhDaoTao, idHocPhan, idNhomTuChon, idDM_LoaiHocPhan, idDM_KhoiKienThuc, phanKy.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| chuong_trinh_id | bigint | FK |
| hoc_phan_id | bigint | FK |
| nhom_tu_chon_id | bigint | FK? |
| phan_ky | int |  |
| loai_hoc_phan | text |  |

Bảng nối quan hệ N:N chương trình–học phần; UNIQUE(chuong_trinh_id,hoc_phan_id) là quy tắc đề xuất. Nhóm tự chọn được chọn phải thuộc cùng chương trình với dòng học phần (FK cặp hoặc kiểm tra tương đương).

### RANG_BUOC_HOC_PHAN — Ràng buộc học phần

Tài nguyên đối chiếu: `tbl_ChuongTrinhDaoTao_HocPhan_RangBuoc`.

Bằng chứng frontend: idChuongTrinhDaoTao, idHocPhan, idHocPhanRangBuoc, idLoaiRangBuoc.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| chuong_trinh_id | bigint | FK |
| hoc_phan_id | bigint | FK |
| hoc_phan_rang_buoc_id | bigint | FK |
| loai_rang_buoc | text |  |

Loại ràng buộc: tiên quyết, học trước, song hành; cần kiểm tra chu trình trong nghiệp vụ.

### NAM_HOC — Năm học

Tài nguyên đối chiếu: `tbl_HeThong_NamHoc`.

Bằng chứng frontend: id, instanceId, ten, nam.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| ma | text | UK |
| nam_bat_dau | int |  |
| nam_ket_thuc | int |  |

### HOC_KY — Học kỳ của năm học

Tài nguyên đối chiếu: `tbl_HeThong_HocKy`.

Bằng chứng frontend: id, instanceId, ten, namHoc, tuNgay, denNgay; nghiệp vụ lọc riêng namHoc và hocKy.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| nam_hoc_id | bigint | FK |
| so_hoc_ky | int |  |
| tu_ngay | date |  |
| den_ngay | date |  |

Đề xuất một bản ghi cho cặp năm học–học kỳ; UNIQUE(nam_hoc_id,so_hoc_ky), không xem học kỳ 1 của mọi năm là cùng bản ghi.

### DOT_DANG_KY — Đợt đăng ký học

Tài nguyên đối chiếu: `tbl_DangKyHoc_DotDangKy`.

Bằng chứng frontend: idDotDangKy dùng trong request; trạng thái đợt có trangThai, chuaQuaHan.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| hoc_ky_id | bigint | FK |
| ten | text |  |
| bat_dau | datetime |  |
| ket_thuc | datetime |  |
| trang_thai | text |  |

Liên kết đợt với học kỳ và thời điểm cụ thể là thiết kế đề xuất.

### LOP_HOC_PHAN — Lớp học phần mở

Tài nguyên đối chiếu: `tbl_Tkb_LopHocPhan`.

Bằng chứng frontend: Đối tượng lớp trả về id, idHocPhan, ten; nghiệp vụ lọc năm học/học kỳ.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| hoc_phan_id | bigint | FK |
| hoc_ky_id | bigint | FK |
| ma_lop | text | UK |
| ten | text |  |
| si_so_toi_da | int |  |

ma_lop và si_so_toi_da là trường thiết kế bổ sung. Một học phần có thể mở nhiều lớp.

### DANG_KY_HOC — Sinh viên đăng ký lớp

Tài nguyên đối chiếu: `tbl_DangKyHoc_LopHocPhan_DanhSach_DangKy`.

Bằng chứng frontend: id, idHocPhan, idLopHocPhan; lọc idNguoiHoc, hocKy, namHoc, trangThai. Request có idDotDangKy, maSinhVien.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK |
| lop_hoc_phan_id | bigint | FK |
| dot_dang_ky_id | bigint | FK |
| ngay_dang_ky | datetime |  |
| trang_thai | text |  |

Frontend gán idNguoiHoc=maSinhVien. Thiết kế này chuẩn hóa mã sinh viên sang FK nội bộ; không khẳng định idNguoiHoc là PK SQL. UNIQUE(sinh_vien_id,lop_hoc_phan_id) phù hợp nếu tái đăng ký cập nhật trạng thái cùng dòng.

### GIANG_VIEN — Giảng viên / cán bộ

Tài nguyên đối chiếu: `tbl_CANBO_HoSo`.

Bằng chứng frontend: Lịch học lookup maCanBo vào code của hồ sơ cán bộ.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| ma_can_bo | text | UK |
| ho_ten | text |  |
| khoa_vien_id | bigint | FK? |

Quan hệ với khoa/viện là đề xuất; một lịch học có thể phân công một cán bộ, đồng giảng cần bảng nối bổ sung.

### PHONG_HOC — Phòng học

Tài nguyên đối chiếu: `tbl_DM_PhongHoc`.

Bằng chứng frontend: Lịch học lookup maPhong vào code của phòng.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| ma_phong | text | UK |
| ten | text |  |
| suc_chua | int |  |

suc_chua là trường thiết kế bổ sung.

### LICH_HOC — Lịch học theo thứ / tiết

Tài nguyên đối chiếu: `tbl_Tkb_LopHocPhan_LichHoc`.

Bằng chứng frontend: idLopHocPhan, maCanBo, maPhong, ngayHoc, tietHoc, soTiet, tuanHocs, tuanHocFulls.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| lop_hoc_phan_id | bigint | FK |
| giang_vien_id | bigint | FK? |
| phong_hoc_id | bigint | FK? |
| thu_trong_tuan | int |  |
| tiet_bat_dau | int |  |
| so_tiet | int |  |

ngayHoc gốc là chỉ số thứ: 6→Chủ nhật, các giá trị khác→thứ ngayHoc+2; không phải kiểu DATE. tietHoc gốc 0-based rồi UI +1. Thiết kế này dùng thu_trong_tuan chuẩn hóa 2..8 và tiết bắt đầu 1-based. Các tuần/giai đoạn áp dụng cần tách bảng khi triển khai đầy đủ. Mã cán bộ/phòng chuyển sang FK nội bộ là đề xuất.

### KET_QUA_HOC_PHAN — Kết quả từng lần học

Tài nguyên đối chiếu: `DiemHocPhan / DiemChiTiet`.

Bằng chứng frontend: namHoc, hocKyTitle, code, ten, soTinChi, diemThanhPhan, diemHe10, diemHe4, diemChu, instanceIdCongThuc.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK |
| hoc_phan_id | bigint | FK |
| hoc_ky_id | bigint | FK |
| lan_hoc | int |  |
| diem_he_10 | decimal |  |
| diem_he_4 | decimal |  |
| diem_chu | text |  |

lan_hoc là trường đề xuất cho học lại/cải thiện. Chưa đủ bằng chứng FK trực tiếp Điểm→ĐăngKý hoặc Điểm→LớpHọcPhần; sơ đồ không vẽ các FK đó.

### DM_KHOAN_THU — Danh mục khoản thu

Tài nguyên đối chiếu: `tbl_DM_KhoanThu`.

Bằng chứng frontend: id, ten; lookup từ khoản thu và chi tiết biên lai.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| ma | text | UK |
| ten | text |  |

### KHOAN_THU_SINH_VIEN — Nghĩa vụ tài chính

Tài nguyên đối chiếu: `tbl_NguoiHoc_KhoanThu`.

Bằng chứng frontend: id, idDM_KhoanThu, maHocPhan, soTien, soTienMienGiam, soTienSauMienGiam, soTienDaNop, soDu, thoiDiemPhatSinh.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK |
| dm_khoan_thu_id | bigint | FK |
| hoc_phan_id | bigint | FK? |
| dang_ky_hoc_id | bigint | FK? |
| hoc_ky_id | bigint | FK? |
| thang_ap_dung | int | ? |
| nam_ap_dung | int | ? |
| so_tien | decimal |  |
| so_tien_mien_giam | decimal |  |
| ngay_phat_sinh | datetime |  |

FK sinh_vien_id và dang_ky_hoc_id là đề xuất, chưa thấy tên cột tương ứng trong DTO tài chính. DTO có namHocHocKy/thang/nam; thiết kế giữ kỳ hoặc tháng/năm áp dụng tùy khoản thu, không bắt buộc tất cả cùng có giá trị. soDu và số đã nộp nên tính từ phân bổ thanh toán đã xác nhận; không cộng giao dịch đang chờ.

### VI_SINH_VIEN — Ví / tài khoản tiền

Tài nguyên đối chiếu: `tbl_NguoiHoc_ViTien`.

Bằng chứng frontend: GetSoDuTaiKhoan trả tongTien.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK + UK |
| so_du | decimal |  |

Một ví trên mỗi sinh viên là lựa chọn thiết kế, chưa xác minh từ API. Số dư cần đối soát với sổ giao dịch; không coi là bằng chứng đã thanh toán mọi khoản thu.

### GIAO_DICH — Giao dịch tài chính

Tài nguyên đối chiếu: `ThanhToanKhoanThu / tbl_NguoiHoc_LichSuGiaoDich`.

Bằng chứng frontend: maThanhToan, maNguoiHoc, soTien, paymentCode, hinhThucThanhToan, danhSachKhoanThuThanhToan.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK |
| vi_id | bigint | FK? |
| ma_giao_dich | text | UK |
| ma_thanh_toan | text | UK? |
| payment_code | text | UK? |
| loai_giao_dich | text |  |
| so_tien | decimal |  |
| trang_thai | text |  |
| thoi_diem | datetime |  |

ma_giao_dich là mã nội bộ đề xuất; maThanhToan và paymentCode được giữ riêng, chưa chứng minh chúng là cùng một mã. Ví là tùy chọn vì có thanh toán trực tiếp qua ngân hàng. Đề xuất loại giao dịch phân biệt NẠP/TRỪ/HOÀN; chỉ loại phù hợp và đã xác nhận mới làm thay đổi số dư ví.

### CT_GIAO_DICH — Phân bổ giao dịch

Tài nguyên đối chiếu: `Bảng nối đề xuất`.

Bằng chứng frontend: Request gửi idsKhoanThu; response có danhSachKhoanThuThanhToan.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| giao_dich_id | bigint | PK + FK |
| khoan_thu_id | bigint | PK + FK |
| so_tien_phan_bo | decimal |  |

Bảng chuẩn hóa N:N giao dịch–khoản thu, hỗ trợ trả nhiều khoản và trả từng phần; chưa thấy tài nguyên SQL tương ứng. Chọn đây là nguồn phân bổ tiền thanh toán đã xác nhận, hoàn tiền dùng phân bổ âm hoặc loại điều chỉnh; không cộng thêm chi tiết biên lai lần thứ hai. Giao dịch nạp tiền có thể không có dòng phân bổ.

### BIEN_LAI — Biên lai thu / chi

Tài nguyên đối chiếu: `tbl_BienLaiThuChi`.

Bằng chứng frontend: id, code, soTienThu, nguoiThu, created, noiDung, kyHieuHoaDon, soHoaDon, isDaHuy.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK |
| giao_dich_id | bigint | FK? |
| ma_bien_lai | text | UK |
| so_tien_thu | decimal |  |
| ngay_tao | datetime |  |
| nguoi_thu | text |  |
| da_huy | boolean |  |

Quan hệ biên lai–giao dịch là đề xuất 0..1 giao dịch/biên lai, một giao dịch có thể có nhiều biên lai. Biên lai không đồng nhất hóa đơn điện tử.

### CT_BIEN_LAI — Chi tiết biên lai

Tài nguyên đối chiếu: `tbl_BienLaiThuChi_ChiTiet`.

Bằng chứng frontend: Mảng trong biên lai; từng dòng có idDM_KhoanThu, soTienNop, soTienRut.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| bien_lai_id | bigint | FK |
| dm_khoan_thu_id | bigint | FK |
| khoan_thu_id | bigint | FK? |
| so_tien_nop | decimal |  |
| so_tien_rut | decimal |  |

bien_lai_id/khoan_thu_id là FK chuẩn hóa đề xuất; chưa có bằng chứng tên cột gốc. Mỗi dòng có thể gắn khoản thu cụ thể; nghiệp vụ thu/chi khác dùng danh mục khoản thu.

### DON_VI_HDDT — Đơn vị nhận hóa đơn

Tài nguyên đối chiếu: `tbl_NguoiHoc_DonViHDDT`.

Bằng chứng frontend: id, tenDonVi, maSoThue, diaChi, email, maQuanHeNganSach, isMacDinh.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| sinh_vien_id | bigint | FK |
| ten_don_vi | text |  |
| ma_so_thue | text |  |
| ma_quan_he_ngan_sach | text |  |
| dia_chi | text |  |
| email | text |  |
| la_mac_dinh | boolean |  |

Mỗi sinh viên tối đa một đơn vị mặc định; các bản ghi khác vẫn được phép tồn tại.

### HOA_DON_DIEN_TU — Hóa đơn và lịch sử

Tài nguyên đối chiếu: `Invoice / thongTinHoaDon`.

Bằng chứng frontend: Invoice: id, maBienLai, invoiceSeries, invoiceNo, totalAmount, issueDate, invoiceStatus. Yêu cầu thông tin hóa đơn có idDonViHDDT. phienBan/isHienHanh thuộc bản ghi lịch sử BIÊN LAI chứa hoaDons[], chưa chứng minh là cột Invoice.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| bien_lai_id | bigint | FK |
| don_vi_hddt_id | bigint | FK? |
| ky_hieu | text |  |
| so_hoa_don | text |  |
| ngay_phat_hanh | datetime |  |
| loai_hoa_don | text |  |
| phien_ban | int |  |
| thong_tin_nguoi_nhan | json |  |
| tong_tien | decimal |  |
| trang_thai | text |  |

Loại PHÁT HÀNH/ĐIỀU CHỈNH/THAY THẾ, phiên bản và snapshot thông tin người nhận là thiết kế bổ sung cần xác nhận. Có thể có nhiều hóa đơn liên quan một biên lai; không cộng tất cả hóa đơn vào tiền đã nộp. Hóa đơn điều chỉnh không tự thay đổi công nợ nếu chưa có nghiệp vụ tài chính tương ứng.

### THONG_BAO — Bài thông báo chung

Tài nguyên đối chiếu: `tbl_ThongBao`.

Bằng chứng frontend: id, instanceId, tieuDe, moTaNgan, noiDung, ngayPhatHanh, nguoiTao, maPhanHe.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| tieu_de | text |  |
| mo_ta_ngan | text |  |
| noi_dung | text |  |
| ngay_phat_hanh | datetime |  |
| nguoi_tao_id | bigint | FK? |
| ma_phan_he | text |  |

Không gộp với thông báo cá nhân. Quan hệ người tạo–tài khoản là đề xuất; tệp đính kèm dùng định danh entity/instanceId và nằm ngoài phạm vi sơ đồ.

### THONG_BAO_CA_NHAN — Thông báo cá nhân

Tài nguyên đối chiếu: `Notification`.

Bằng chứng frontend: id, message.content, message.time, message.link, read:[{userId}].

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| id | bigint | PK |
| noi_dung | text |  |
| thoi_diem | datetime |  |
| lien_ket | text |  |

Đây là thực thể thông báo cá nhân theo service, không khẳng định bảng SQL. Quan hệ phân phối người nhận chưa đủ bằng chứng để thiết kế trong phạm vi này.

### LUOT_DOC_THONG_BAO — Trạng thái đã đọc

Tài nguyên đối chiếu: `Bảng nối đề xuất từ Notification.read`.

Bằng chứng frontend: MarkReadById/{id} nhận userId; read là mảng userId.

| Cột đề xuất | Kiểu đề xuất | Vai trò |
|---|---|---|
| thong_bao_id | bigint | PK + FK |
| tai_khoan_id | bigint | PK + FK |
| doc_luc | datetime |  |

Bảng nối lưu trạng thái đọc, không phải danh sách người nhận. doc_luc là trường bổ sung đề xuất.

## Quan hệ

| Bảng cha | Bảng con | FK đề xuất ở bảng con | Căn cứ |
|---|---|---|---|
| KHOA_VIEN | NGANH_HOC | khoa_vien_id | Đề xuất: Tổ chức ngành theo khoa/viện |
| NGANH_HOC | LOP_HANH_CHINH | nganh_id | Frontend có liên kết: Lớp lọc theo idNganh |
| KHOA_HOC | LOP_HANH_CHINH | khoa_hoc_id | Frontend có liên kết: Lớp lọc theo idKhoaHoc |
| LOP_HANH_CHINH | SINH_VIEN | lop_hanh_chinh_id | Frontend có liên kết: Form hồ sơ có idLopHanhChinh; chưa xác nhận tương đương idLopHienTai |
| NGANH_HOC | SINH_VIEN | nganh_id | Frontend có liên kết: Hồ sơ có idNganh |
| KHOA_HOC | SINH_VIEN | khoa_hoc_id | Frontend có liên kết: Hồ sơ có idKhoaHoc |
| SINH_VIEN | TAI_KHOAN | sinh_vien_id | Frontend có liên kết: Tài khoản có maNguoiHoc; cardinality chưa xác minh |
| NGANH_HOC | CHUONG_TRINH_DAO_TAO | nganh_id | Frontend có liên kết: CTĐT có idNganh |
| KHOA_HOC | CHUONG_TRINH_DAO_TAO | khoa_hoc_id | Frontend có liên kết: CTĐT có idKhoaHoc |
| SINH_VIEN | SINH_VIEN_CTDT | sinh_vien_id | Frontend có liên kết: tbl_NguoiHoc_Lop lọc idNguoiHoc; FK nội bộ đề xuất |
| CHUONG_TRINH_DAO_TAO | SINH_VIEN_CTDT | chuong_trinh_id | Frontend có liên kết: tbl_NguoiHoc_Lop có idChuongTrinhDaoTao |
| CHUONG_TRINH_DAO_TAO | NHOM_TU_CHON | chuong_trinh_id | Frontend có liên kết: Nhóm có idChuongTrinhDaoTao |
| CHUONG_TRINH_DAO_TAO | CTDT_HOC_PHAN | chuong_trinh_id | Frontend có liên kết: Join idChuongTrinhDaoTao |
| HOC_PHAN | CTDT_HOC_PHAN | hoc_phan_id | Frontend có liên kết: Join idHocPhan |
| NHOM_TU_CHON | CTDT_HOC_PHAN | nhom_tu_chon_id | Frontend có liên kết: Join idNhomTuChon |
| CHUONG_TRINH_DAO_TAO | RANG_BUOC_HOC_PHAN | chuong_trinh_id | Frontend có liên kết: Ràng buộc trong chương trình |
| HOC_PHAN | RANG_BUOC_HOC_PHAN | hoc_phan_id | Frontend có liên kết: Học phần chịu ràng buộc |
| HOC_PHAN | RANG_BUOC_HOC_PHAN | hoc_phan_rang_buoc_id | Frontend có liên kết: Học phần tiên quyết / liên quan |
| NAM_HOC | HOC_KY | nam_hoc_id | Frontend có liên kết: Frontend có cặp năm học–học kỳ; FK nội bộ là đề xuất |
| HOC_KY | DOT_DANG_KY | hoc_ky_id | Đề xuất: Đợt đăng ký thuộc học kỳ trong thiết kế |
| HOC_PHAN | LOP_HOC_PHAN | hoc_phan_id | Frontend có liên kết: Đối tượng lớp có idHocPhan |
| HOC_KY | LOP_HOC_PHAN | hoc_ky_id | Đề xuất: Chuẩn hóa namHoc/hocKy của lớp |
| SINH_VIEN | DANG_KY_HOC | sinh_vien_id | Frontend có liên kết: Lọc idNguoiHoc=maSinhVien |
| LOP_HOC_PHAN | DANG_KY_HOC | lop_hoc_phan_id | Frontend có liên kết: Đăng ký có idLopHocPhan |
| DOT_DANG_KY | DANG_KY_HOC | dot_dang_ky_id | Frontend có liên kết: Liên kết request nghiệp vụ idDotDangKy; FK lưu trữ chưa xác minh |
| KHOA_VIEN | GIANG_VIEN | khoa_vien_id | Đề xuất: Cán bộ trực thuộc khoa/viện: thiết kế bổ sung |
| LOP_HOC_PHAN | LICH_HOC | lop_hoc_phan_id | Frontend có liên kết: Lịch có idLopHocPhan |
| GIANG_VIEN | LICH_HOC | giang_vien_id | Frontend có liên kết: maCanBo đối chiếu hồ sơ code |
| PHONG_HOC | LICH_HOC | phong_hoc_id | Frontend có liên kết: maPhong đối chiếu phòng code |
| SINH_VIEN | KET_QUA_HOC_PHAN | sinh_vien_id | Đề xuất: Kết quả cá nhân; FK chưa xác minh |
| HOC_PHAN | KET_QUA_HOC_PHAN | hoc_phan_id | Frontend có liên kết: Kết quả / bộ lọc học phần |
| HOC_KY | KET_QUA_HOC_PHAN | hoc_ky_id | Frontend có liên kết: Kết quả có namHoc/hocKy; FK nội bộ đề xuất |
| SINH_VIEN | KHOAN_THU_SINH_VIEN | sinh_vien_id | Đề xuất: Khoản thu người học; chưa thấy FK DTO |
| DM_KHOAN_THU | KHOAN_THU_SINH_VIEN | dm_khoan_thu_id | Frontend có liên kết: idDM_KhoanThu lookup DM.id |
| HOC_PHAN | KHOAN_THU_SINH_VIEN | hoc_phan_id | Frontend có liên kết: maHocPhan lookup HocPhan.code |
| DANG_KY_HOC | KHOAN_THU_SINH_VIEN | dang_ky_hoc_id | Đề xuất: Đề xuất nguồn khoản thu học phí từ đăng ký |
| HOC_KY | KHOAN_THU_SINH_VIEN | hoc_ky_id | Đề xuất: Chuẩn hóa namHocHocKy thành FK kỳ; khoản thu theo tháng có thể để rỗng |
| SINH_VIEN | VI_SINH_VIEN | sinh_vien_id | Đề xuất: Một ví/sinh viên là lựa chọn thiết kế |
| SINH_VIEN | GIAO_DICH | sinh_vien_id | Frontend có liên kết: Thanh toán có maNguoiHoc |
| VI_SINH_VIEN | GIAO_DICH | vi_id | Đề xuất: Chỉ giao dịch có liên quan ví |
| GIAO_DICH | CT_GIAO_DICH | giao_dich_id | Đề xuất: Chuẩn hóa phân bổ N:N |
| KHOAN_THU_SINH_VIEN | CT_GIAO_DICH | khoan_thu_id | Frontend có liên kết: Request idsKhoanThu / response danh sách |
| SINH_VIEN | BIEN_LAI | sinh_vien_id | Đề xuất: Biên lai của người học; FK chưa thấy |
| GIAO_DICH | BIEN_LAI | giao_dich_id | Đề xuất: Liên kết đối soát giao dịch–biên lai |
| BIEN_LAI | CT_BIEN_LAI | bien_lai_id | Frontend có liên kết: Mảng tbl_BienLaiThuChi_ChiTiet |
| DM_KHOAN_THU | CT_BIEN_LAI | dm_khoan_thu_id | Frontend có liên kết: Chi tiết có idDM_KhoanThu |
| KHOAN_THU_SINH_VIEN | CT_BIEN_LAI | khoan_thu_id | Đề xuất: Đề xuất đối soát dòng biên lai với khoản thu |
| SINH_VIEN | DON_VI_HDDT | sinh_vien_id | Đề xuất: Đơn vị xuất hóa đơn được lưu theo người học |
| BIEN_LAI | HOA_DON_DIEN_TU | bien_lai_id | Frontend có liên kết: maBienLai và lịch sử nhiều hóa đơn; FK/cardiinality đề xuất |
| DON_VI_HDDT | HOA_DON_DIEN_TU | don_vi_hddt_id | Đề xuất: idDonViHDDT chỉ thấy trong yêu cầu; FK lưu trong Invoice chưa xác minh |
| TAI_KHOAN | THONG_BAO | nguoi_tao_id | Đề xuất: Đề xuất người tạo tham chiếu danh tính |
| THONG_BAO_CA_NHAN | LUOT_DOC_THONG_BAO | thong_bao_id | Frontend có liên kết: Notification.id và read[] |
| TAI_KHOAN | LUOT_DOC_THONG_BAO | tai_khoan_id | Frontend có liên kết: MarkReadById nhận userId |

## Quy tắc thiết kế cần xác nhận

1. `CTDT_HOC_PHAN` nối N:N chương trình–học phần; `SINH_VIEN_CTDT` cho phép người học theo chương trình chính/ngành hai; `DANG_KY_HOC` nối N:N sinh viên–lớp học phần. Một môn có thể được học lại qua các lớp và học kỳ khác nhau. Nhóm tự chọn phải thuộc cùng CTĐT với dòng CTDT_HOC_PHAN, cần FK cặp hoặc kiểm tra tương đương.
2. `HOC_KY` là một kỳ của một năm cụ thể. `KHOA_HOC` là khóa tuyển sinh và không thay thế `NAM_HOC`.
3. Chưa đủ bằng chứng để gắn kết quả điểm trực tiếp với một dòng đăng ký hay một lớp. Mô hình kết quả lưu theo người học, học phần, kỳ và lần học; cần xác nhận quy tắc quy đổi học lại/cải thiện và bảng điểm thành phần.
4. `CT_GIAO_DICH` là nguồn phân bổ N:N tiền thanh toán đã xác nhận cho các khoản thu; tổng phân bổ và số tiền giao dịch phải đối soát theo loại giao dịch. Chi tiết biên lai là chứng từ/đối soát, không cộng thêm lần thứ hai vào số tiền đã nộp. Giao dịch nạp ví có thể không có phân bổ khoản thu; thanh toán chuyển khoản trực tiếp không tự tăng ví. Phải xử lý chờ, thành công, thất bại, hủy/hoàn tiền; hoàn tiền dùng phân bổ âm hoặc loại điều chỉnh và mã giao dịch duy nhất để tránh ghi nhận hai lần.
5. Biên lai và hóa đơn điện tử là hai thực thể khác nhau. phienBan/isHienHanh quan sát thuộc lịch sử biên lai, chưa chứng minh thuộc Invoice. Mô hình lưu loại phát hành/điều chỉnh/thay thế, phiên bản và snapshot người nhận như quy tắc đề xuất; quan hệ phiên bản và tính hiện hành cần xác nhận. Không cộng mọi hóa đơn vào tiền đã nộp, hóa đơn điều chỉnh không tự giảm công nợ.
6. `VI_SINH_VIEN.sinh_vien_id` đề xuất duy nhất. Cần cơ chế sổ giao dịch/đối soát để bảo đảm số dư, không chỉ sửa số dư trực tiếp.
7. `THONG_BAO` là bài công bố; `THONG_BAO_CA_NHAN` là notification. `LUOT_DOC_THONG_BAO` lưu ai đã đọc, không thay cho danh sách người nhận.
8. Không đề xuất xóa cascade dữ liệu điểm, đăng ký và tài chính theo việc xóa hồ sơ sinh viên; cần chính sách lưu trữ lịch sử và khóa tham chiếu khi triển khai.
9. Các danh mục hệ đào tạo, loại học phần, khối kiến thức, giai đoạn/tuần lịch, điểm thành phần, tệp đính kèm, phân quyền và các dịch vụ khác chưa được triển khai thành bảng riêng trong phạm vi này. Mô hình hiện tại không khẳng định bao phủ toàn bộ hệ thống USMART.

## Nguồn đối chiếu cụ thể

- `/sv/main.cdf3b053a3ca2ee8f8b6.js`: service hồ sơ, CTĐT, học phần, danh tính, notification.
- `/sv/11.45583478bed7f7922bc0.js`: đăng ký học, idDotDangKy/maSinhVien/idLopHocPhans, lịch lớp và join mã phòng/cán bộ.
- `/sv/9.feae2ca3928b4009cc1d.js`: bảng điểm, DiemHocPhan và DiemChiTiet.
- `/sv/13.d6d15cdd0b792b864523.js`: hồ sơ người học.
- `/sv/20.285e48b2f815a3fc4c56.js`: thời khóa biểu theo người học/năm/học kỳ.
- `/sv/3.713a9fd397ccd10f8845.js`, `/sv/24.6e1beb096fa5ebace277.js`: khoản thu, biên lai và thông tin hóa đơn.
- `/sv/14.4a1ee0562bae047682ee.js`, `/sv/15.20cd3d77caf162cf6162.js`: hóa đơn, nạp tiền và kết quả giao dịch.
- `/sv/27.3e5424c992c6edfd00f8.js`: bài thông báo.
- `/user/assets/environments/prod.json`: cấu hình public chỉ ra frontend gọi các gateway nghiệp vụ và issuer OIDC. Không suy ra DBMS hay kiến trúc triển khai từ tên gateway.

Để xác nhận ERD vật lý, cần DDL/migration/ORM schema hoặc tài liệu CSDL do người quản trị cung cấp. Đăng nhập tài khoản sinh viên chỉ cho phép khảo sát hành vi và dữ liệu tài khoản, không tự cung cấp cấu trúc CSDL.